package com.proyecto.app.service;

import com.proyecto.app.commons.Generic;
import com.proyecto.app.models.Personal;

public interface PersonalService extends Generic<Personal, Integer>{

}
