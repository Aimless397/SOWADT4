package com.proyecto.app.repository;


import org.springframework.data.repository.CrudRepository;

import com.proyecto.app.models.Cliente;


public interface ClienteRepository extends CrudRepository<Cliente, Integer>{

	
}
