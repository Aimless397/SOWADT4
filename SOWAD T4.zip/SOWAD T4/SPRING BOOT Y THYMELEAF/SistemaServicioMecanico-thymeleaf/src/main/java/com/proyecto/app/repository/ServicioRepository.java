package com.proyecto.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.proyecto.app.models.Servicio;

public interface ServicioRepository extends CrudRepository<Servicio, Integer> {

}
