package com.proyecto.app.service;

import com.proyecto.app.commons.Generic;
import com.proyecto.app.models.ServicioMecanicoDet;

public interface ServicioMecanicoDetService extends Generic<ServicioMecanicoDet, Integer>{

}
