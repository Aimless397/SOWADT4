package com.proyecto.app.service;

import com.proyecto.app.commons.Generic;
import com.proyecto.app.models.Servicio;


public interface ServicioService extends Generic<Servicio, Integer> {

}
