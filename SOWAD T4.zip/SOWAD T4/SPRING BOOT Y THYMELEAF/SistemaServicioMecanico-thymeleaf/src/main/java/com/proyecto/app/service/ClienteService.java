package com.proyecto.app.service;

import com.proyecto.app.commons.Generic;
import com.proyecto.app.models.Cliente;

public interface ClienteService extends Generic<Cliente, Integer> {

}
