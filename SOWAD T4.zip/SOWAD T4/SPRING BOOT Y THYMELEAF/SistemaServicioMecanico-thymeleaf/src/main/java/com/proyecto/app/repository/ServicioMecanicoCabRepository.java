package com.proyecto.app.repository;

import org.springframework.data.repository.CrudRepository;
import com.proyecto.app.models.ServicioMecanicoCab;

public interface ServicioMecanicoCabRepository extends CrudRepository<ServicioMecanicoCab, Integer>{

}
