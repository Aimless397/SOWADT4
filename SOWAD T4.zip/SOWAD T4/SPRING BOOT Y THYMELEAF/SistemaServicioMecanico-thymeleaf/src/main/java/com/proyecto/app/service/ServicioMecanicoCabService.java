package com.proyecto.app.service;

import com.proyecto.app.commons.Generic;
import com.proyecto.app.models.ServicioMecanicoCab;

public interface ServicioMecanicoCabService extends Generic<ServicioMecanicoCab, Integer> {

}
