package com.proyecto.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaServicioMecanicoThymeleafApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaServicioMecanicoThymeleafApplication.class, args);
	}

}
