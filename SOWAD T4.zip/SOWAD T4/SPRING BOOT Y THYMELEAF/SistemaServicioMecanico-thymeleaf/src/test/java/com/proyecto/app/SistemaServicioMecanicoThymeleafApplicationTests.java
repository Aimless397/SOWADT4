package com.proyecto.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaServicioMecanicoThymeleafApplicationTests {

	@Test
	void contextLoads() {
	}

}
